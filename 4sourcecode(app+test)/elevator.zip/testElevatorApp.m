classdef testElevatorApp < matlab.uitest.TestCase
    properties
        F1
        F2
        F3
        E1UI
        E2UI
        E1
        E2
    end
    methods(TestMethodSetup)
        function launchApp(testCase)
            
            testCase.F1=control_pannel;
            testCase.F2=control_pannel;
            testCase.F3=control_pannel;
            testCase.F1.setid(1);
            testCase.F2.setid(2);
            testCase.F3.setid(3);
            
            ctl_core = controller_core;
            testCase.E1UI=elevatorUI;
            testCase.E2UI=elevatorUI;
            
            testCase.E1=elevator(1,ctl_core,testCase.E1UI,testCase.F1,testCase.F2,testCase.F3);
            testCase.E2=elevator(2,ctl_core,testCase.E2UI,testCase.F1,testCase.F2,testCase.F3);
            
            testCase.F1.cc=ctl_core;
            testCase.F2.cc=ctl_core;
            testCase.F3.cc=ctl_core;
            
            testCase.E1UI.id=1;
            testCase.E1UI.cc=ctl_core;
            testCase.E1UI.resize();
            testCase.E2UI.id=2;
            testCase.E2UI.cc=ctl_core;
            testCase.E2UI.resize();
            
            ctl_core.setE1(testCase.E1);
            ctl_core.setE2(testCase.E2);
        end
    end
    methods (Test)
        function test_Evevatorfunction(testCase)
            %test one single elevator open and close
            
            testCase.E1.status = 0;
            display(testCase.E1.upq);
            WAKE(testCase.E1.sf);
            UP(testCase.E1.sf);
            %testCase.E1.inposition();
            testCase.E1.upq = [1];
            display(testCase.E1.upq);
            WAKE(testCase.E1.sf);
            testCase.verifyEqual(testCase.E1.floor, 1);
            
            testCase.addTeardown(@delete,testCase.F1);
            testCase.addTeardown(@delete,testCase.F2);
            testCase.addTeardown(@delete,testCase.F3);
            testCase.addTeardown(@delete,testCase.E1UI);
            testCase.addTeardown(@delete,testCase.E2UI);
        end
    end
end